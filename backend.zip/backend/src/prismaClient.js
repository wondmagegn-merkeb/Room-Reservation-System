// ES6 format
import { PrismaClient } from '@prisma/client';
export const prisma = new PrismaClient();  // Export the prisma instance
